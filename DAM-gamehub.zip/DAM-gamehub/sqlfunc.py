# -*- coding: utf-8 -*-

import pandas as pd
import pymysql
from sqlalchemy import create_engine
from datetime import datetime

# 这种是用create_engine连接，对数据用pandas操作
engine = create_engine('mysql+pymysql://root:password@127.0.0.1:3306/gamehub')

# 这种是用pymysql，可以直接上sql语句
conn = pymysql.connect(user='root', passwd='password', db='gamehub')
conn.autocommit(True)
cur = conn.cursor()

#用print输出dataframe时候展示全部信息
pd.set_option('display.width', 1000) # 设置字符显示宽度
pd.set_option('display.max_rows', None) # 设置显示最大行
pd.set_option('display.max_columns', None) # 设置显示最大行



def showTable(tableName):
    sql = "select * from " + tableName
    try:
        data = pd.read_sql(sql, engine)
        return data
    except Exception as e:
        print(e)

    return


def insertData(data, tableName):
    try:
        data.to_sql(name=tableName, con=engine, if_exists='append', index=False)
        return 1
    except Exception as e:
        print(e)

    return 0


# select * from tableName where field = target
def selectAllData(tableName, field, target):
    sql = "select * from " + tableName + " where " + field + " = '" + target + "'"
    try:
        result= pd.read_sql(sql, engine)
        return result
    except Exception as e:
        print(e)

    return



def signUp(_username, _password, _vip):
    result = selectAllData('users', 'username',_username)
    if result.empty==1:
        user_info = pd.DataFrame()
        user_info['username'] = [_username]
        user_info['password'] = [_password]
        user_info['vip'] = [_vip]
        if insertData(user_info, 'users')==1:
            print('Create your account successfully!')
            return 1
    else:
        print('The username already exists!')
    return 0



def logIn(_username, _password):
    data = selectAllData('users', 'username', _username)
    if data.empty or len(data['username']) != 1:
        print('Incorrect username!')
        return 0
    elif data['password'][0] == _password:
        print('Log in successfully!')
        return 1
    else:
        print('Incorrect password!')
        return 0


def getVip(_username):
    sql = "select * from users where username = '%s'" % (_username)
    try:
        result = pd.read_sql(sql, engine)
        if result.empty == 1:  # 用户不存在
            print("User doesn't exit!")
            return -1
        else:
            return result['vip'][0]
    except Exception as e:
        print(e)

    return -1

def setVip(_username, _vip):
    try:
        cur.execute("UPDATE users SET vip = %d WHERE username = '%s'" % (_vip, _username))
        print('Change Vip successfully!')
        return 1
    except Exception as e:
        print(e)

    return 0

def createRepo(_repo_name, _owner,_isPrivate,_description):
    result= getRepoID(_repo_name, _owner)
    if result != -1:
        print('Repo name of this owner already exist!')
        return 0
    else:
        Repo_info = pd.DataFrame()
        Repo_info['repo_name'] = [_repo_name]
        Repo_info['owner'] = [_owner]
        Repo_info['isPrivate'] = [_isPrivate]
        Repo_info['description'] = [_description]
        if insertData( Repo_info, 'repos') ==1:
            id = getRepoID(_repo_name, _owner)
            if createRight(_owner,  id , 1)==1:
                print( 'Create new Repo successfully!')
                return 1
    return 0

def getRepoID(_repo_name,_owner):
    sql = "select repo_id from repos where repo_name = '" + _repo_name + "' and owner = '" +_owner+"'"
    try:
        result = pd.read_sql(sql, engine)
        if result.empty != 1:
            return (result.ix[[0]].values[0][0])
        else:  # empty
            print("The repo_id don's exist!")
            return -1
    except Exception as e:
        print(e)
        return -1

def isUserExist(_username):
    sql = "select * from users where username = '%s'" % (_username)
    try:
        result = pd.read_sql(sql, engine)
        if result.empty==1:# 用户不存在
            return 0
        else:
            return 1
    except Exception as e:
        print(e)

    return -1


def getRepoInfo(_repo_id):
    sql = "select * from repos where repo_id = %d"% (_repo_id)
    try:
        result = pd.read_sql(sql, engine)
        return result
    except Exception as e:
        print(e)

    return

def getRepoAllRight(_repo_id):
    sql = "select * from rights where repo_id = %d" % (_repo_id)
    try:
        result = pd.read_sql(sql, engine)
        return result
    except Exception as e:
        print(e)

    return

def getRepoPartnerRight(_repo_id):
    info= getRepoInfo(_repo_id)
    if info.empty==1:
        print("The Repo doesn't exist")
        return
    _owner = info['owner'][0]
    # _owner =str(info['owner'][0])
    sql = "select * from rights where repo_id = %d and username <> '%s' " % (_repo_id, _owner)
    try:
        result = pd.read_sql(sql, engine)
        return result
    except Exception as e:
        print(e)

    return


def getRepoLog(_repo_id):
    sql = "select * from logs where repo_id = %d" %(_repo_id)
    try:
        result = pd.read_sql(sql, engine)
        return result
    except Exception as e:
        print(e)

    return

def getUserRepoID(_username):
    if isUserExist(_username) != 1:
        print("User doesn't exist!")
        return

    sql = "select repo_id from rights where username = '%s'" % (_username)
    try:
        result = pd.read_sql(sql, engine)
        return result
    except Exception as e:
        print(e)

    return

def getOwnerRepoID(_username):
    if isUserExist(_username)!= 1:
        print("User doesn't exist!")
        return
    sql = "select repo_id from repos where owner = '%s'" % (_username)
    try:
        result = pd.read_sql(sql, engine)
        return result
    except Exception as e:
        print(e)

    return

def getPartnerRepoID(_username):
    if isUserExist(_username) != 1:
        print("User doesn't exist!")
        return
    ownerRepoID= getOwnerRepoID(_username)
    userRepoID= getUserRepoID(_username)
    if userRepoID.empty==1:
        return
    if ownerRepoID.empty==1:
        return userRepoID

    return userRepoID.drop(labels=ownerRepoID.axes[0])



def getRepoIDByLevel(_username,_level):
    if isUserExist(_username) != 1:
        print("User doesn't exist!")
        return
    sql = "select repo_id from rights where username = '%s' and level = %d " % (_username,_level)
    try:
        result = pd.read_sql(sql, engine)
        return result
    except Exception as e:
        print(e)

    return

def deleteRepo(_repo_id):
    try:

        cur.execute("delete from rights where repo_id = %d " % (_repo_id))
        print('Delete relevant Repo rights successfully!')


        cur.execute("delete from logs where repo_id = %d " % (_repo_id))
        print('Delete relevant Repo logs successfully!')

        cur.execute("delete from repos where repo_id =%d " % (_repo_id))
        print('Delete a Repo successfully!')

        return 1
    except Exception as e:
        print(e)

    return 0


def setRepoPrivate(_repo_id, _isPrivate):
    try:
        cur.execute("UPDATE repos SET isPrivate = %d WHERE repo_id = %d" % (_isPrivate, _repo_id))
        print('Change Repo isPrivate successfully!')
        return 1
    except Exception as e:
        print(e)

    return 0

def setRepoDescription(_repo_id, _description):
    try:
        cur.execute("UPDATE repos SET description = '%s' WHERE repo_id = %d" % (_description, _repo_id))
        print('Change Repo Description successfully!')
        return 1
    except Exception as e:
        print(e)

    return 0


def createLog(_repo_id, _event,_comment,_log_time):
    Log_info = pd.DataFrame()
    Log_info['repo_id'] = [_repo_id]
    Log_info['event'] = [_event]
    Log_info['comment'] = [_comment]
    Log_info['log_time'] = [_log_time]
    if insertData(Log_info, 'logs')==1:
        print('Create new Log successfully!')
        return 1

    return 0


def createRight(_username, _repo_id,_level):
    if isUserExist(_username)!= 1:
        print("User doesn't exist!")
        return 0

    if getRight(_username, _repo_id)==-1: # the right don't exist
        Right_info = pd.DataFrame()
        Right_info['username'] = [_username]
        Right_info['repo_id'] = [_repo_id]
        Right_info['level'] = [_level]
        if insertData(Right_info, 'rights') == 1:
            print('Create new Right successfully!')
            return 1
    else:
        print("The Right already exist!")
        return 0

    return 0

def getRight(_username,_repo_id):
    try:
        sql = "select level from rights where username = '%s' and repo_id = %d" %(_username,_repo_id)
        result = pd.read_sql(sql, engine)
        if result.empty != 1:
            return (result.ix[[0]].values[0][0])
        else:  # empty
            return -1
    except Exception as e:
        print(e)
    return -1

def setRight(_username, _repo_id,_level):
    right= getRight(_username, _repo_id)
    if right==-1:
        print("The Right don's exist!")
        return 0
    try:
        cur.execute("UPDATE rights SET level = %d WHERE username = '%s' and repo_id = %d" % (_level, _username, _repo_id))
        print('Change Right successfully!')
        return 1
    except Exception as e:
        print(e)

    return 0


def deleteRight(_username, _repo_id):
    try:
        cur.execute("delete from rights where username ='%s' and repo_id = %d " % (_username, _repo_id))
        print('Delete a Right successfully!')
        return 1
    except Exception as e:
        print(e)

    return 0

def searchMyRepo(_username,_keyword):
    if isUserExist(_username)!= 1:
        print("User doesn't exist!")
        return
    else:
        try:
            sql = "select * from repos where owner = '" + _username + "' and repo_name LIKE '%%" + _keyword + "%%'"
            result = pd.read_sql(sql, engine)
            return result
        except Exception as e:
            print(e)

        return

def searchAllRepo(_keyword):
    try:
        sql = "select * from repos where repo_name LIKE '%%" + _keyword + "%%'"
        result = pd.read_sql(sql, engine)
        return result
    except Exception as e:
        print(e)

    return
'''

signUp('user2','123456', 0)
signUp('user3','123456', 0)
logIn('user1','123456')
logIn('user1','123457')
logIn('user100','123457')
logIn('user2','123457')
logIn('user2','123456')
print(showTable('Users'))
setVip('user2', 2)
print(showTable('Users'))

createRepo('MyVRGame3','user3',1,'my first VR Game3 reposity')
createRepo('MyVRGame3','user3',1,'my first VR Game3 reposity')

setRepoPrivate(getRepoID('MyVRGame3','user3'),0)
setRepoDescription(getRepoID('MyVRGame3','user3'),'again!! my first VR Game3 reposity')

createRepo('MyVRGame4','user4',1,'my first VR Game4 reposity')
signUp('user4','123456', 0)
signUp('user4','123456', 0)

createRepo('MyVRGame4','user4',1,'my first VR Game4 reposity')

createRight('user3',getRepoID('MyVRGame3','user3'),1)
createRight('user4',getRepoID('MyVRGame3','user3'),1)

getRight('user4',getRepoID('MyVRGame3','user3'))
setRight('user4',getRepoID('MyVRGame3','user3'),0)

createRepo('My3DGame3','user3',1,'my first 3D Game3 reposity')
createRepo('My3DGame4','user4',1,'my first 3D Game4 reposity')
print(searchMyRepo('user3','3D'))
print(searchMyRepo('user4','VR'))
print(searchAllRepo('Game'))
print(searchAllRepo('Game')['description'][0])
print(searchAllRepo('Game')['description'].__len__())
print(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
createLog(getRepoID('MyVRGame3','user3'), "created","happy!",datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
createLog(getRepoID('MyVRGame3','user3'), "checked","sad!",datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

# new test

createRepo('MyVRGame3','user3',1,'my first VR Game3 reposity')
id= getRepoID('MyVRGame3','user3')

createRight('user2',id,0)
setRight('user2',id,0)

setRight('user3',id,1)
print(getRepoLog(id))
print("********")
print(getRepoInfo(id))
print("********getRepoAllRight:")
print(getRepoAllRight(id))
print("********getRepoPartnerRight:")
print(getRepoPartnerRight(id))
print("********getUserRepoID:")
print(getUserRepoID('user4'))
print("********getOwnerRepoID:")
print(getOwnerRepoID('user4'))
print("********getPartnerRepoID:")
print(getPartnerRepoID('user4'))
print(getRepoIDByLevel('user4',0))
print(getRepoIDByLevel('user4',1))


print(getVip('userXXXX'))
print(getVip('user3'))

'''


# repo_id=getUserRepoID('yjj')
# repos_info = []
# for i in range(len(repo_id)):
#     repo_info = getRepoInfo(repo_id.iloc[i].repo_id)
#     # print repo_info.loc['repo_id']
#     repos_info.append(repo_info)
# print type(repos_info[0]['repo_id'][0])

# repo_info = getRepoInfo(5)
# print repo_info['repo_name'][0]


print getRepoInfo(5)['isPrivate'][0]