# -*- coding: utf-8 -*-
import oss2
import os

# 阿里云主账号AccessKey拥有所有API的访问权限
# 请修改为您自己的账号
auth = oss2.Auth('XXXXXXXXX', 'XXXXXXXXX')
bucket = oss2.Bucket(auth, 'http://oss-cn-hangzhou.aliyuncs.com', 'gamehub')


def uploadFile(repoId, fileName, localPath, uploader):
    try:
        object_name = str(repoId) + '/' + fileName
        bucket.put_object_from_file(object_name, localPath)
        bucket.update_object_meta(object_name, headers={'x-oss-meta-uploader': uploader,
                                                    'x-oss-meta-tag0': '', 'x-oss-meta-tag1': '', 'x-oss-meta-tag2': '',
                                                    'x-oss-meta-tag3': '', 'x-oss-meta-tag4': ''})
        print("uploadFile successfully!")
        return 1
    except Exception as e:
        print('exception')
        print(e)
        return 0  # error occur


# uploadFile(1, 'hello3.pdf', '/Users/yaolu/Desktop/关于国家发明专利的编写说明.pdf', 'yaolu')
# uploadFile(1, 'SampleScene.unity', '/Users/yaolu/Desktop/SampleScene.unity', 'yaolu')
# uploadFile(1, '一种基于区块链和数字水印的数字资源侵权追踪方法-姚璐.docx', '/Users/yaolu/Desktop/一种基于区块链和数字水印的数字资源侵权追踪方法-姚璐.docx', 'zxy')

def downloadFile(repoId, fileName, localPath):
    try:
        object_name = str(repoId) + '/' + fileName
        bucket.get_object_to_file(object_name, localPath)
        print("downloadFile successfully!")
        return 1
    except:
        return 0

# downloadFile(1, 'SampleScene.unity', '/Users/yaolu/Downloads/SampleScene.unity')


def existsFile(repoId, fileName):
    object_name = str(repoId) + '/' + fileName
    exist = bucket.object_exists(object_name)
    return exist


def deleteFile(repoId, fileName):
    try:
        object_name = str(repoId) + '/' + fileName
        bucket.delete_object(object_name)
        print("deleteFile successfully!")
        return 1
    except:
        return 0

# deleteFile(1, 'hello.pdf')


def updateMeta(repoId, fileName, tags):
    try:
        object_name = str(repoId) + '/' + fileName
        meta = bucket.head_object(object_name)
        header = {'x-oss-meta-uploader': meta.headers['x-oss-meta-uploader']}
        for index, value in enumerate(tags):
            header['x-oss-meta-tag'+str(index)] = value
        bucket.update_object_meta(object_name, headers=header)
        print("updateMeta successfully!")
        return 1
    except:
        return 0


# tags = ['a111', 'b222', 'c333', 'd444', 'e555']
# updateMeta(1, 'hello.pdf', tags)


def listFiles(repoId):
    files = []
    for obj in oss2.ObjectIterator(bucket, prefix=str(repoId) + '/'):
        files.append(obj.key[obj.key.find('/')+1:])
    return files

# print(listFiles(13))


def deleteRepo(repoId):
    try:
        files = listFiles(repoId)
        bucket.batch_delete_objects(files)
        print("deleteRepo in oss successfully!")
        return 1
    except:
        return 0

# deleteRepo(2)

# result = bucket.head_object('2/hello.pdf')
# print(result.headers['x-oss-meta-uploader'])


def getMeta(repoId, fileName):
    # print repoId
    # print str(fileName)
    object_name = str(repoId) + '/' + fileName
    meta = bucket.head_object(object_name).headers
    size = str(int(bucket.get_object_meta(object_name).headers['Content-Length'])/1024)+'KB'
    # info = [str(repoId), fileName, meta['x-oss-meta-uploader'], meta['Last-Modified'], size, meta['x-oss-meta-tag0'], meta['x-oss-meta-tag1'], meta['x-oss-meta-tag2'], meta['x-oss-meta-tag3'], meta['x-oss-meta-tag4']]
    info={}
    info['repoId'] = str(repoId)
    info['fileName'] = fileName
    info['uploader'] = meta['x-oss-meta-uploader']
    info['updateTime'] = meta['Last-Modified']
    info['size'] = size
    info['meta0'] = meta['x-oss-meta-tag0']
    info['meta1'] = meta['x-oss-meta-tag1']
    info['meta2'] = meta['x-oss-meta-tag2']
    info['meta3'] = meta['x-oss-meta-tag3']
    info['meta4'] = meta['x-oss-meta-tag4']
    return info

# metadata = getMeta(13, 'SampleScene.unity')
# print metadata


def searchRepo(repoId, keyword):
    targetFile = []
    files = listFiles(repoId)
    for file in files:
        file = str(repoId) + '/' + file
        if keyword in file:  # search by file name
            targetFile.append(file)
        else:  # search by metadata
            meta = bucket.head_object(file).headers
            if keyword in meta['x-oss-meta-uploader'] \
                    or keyword in meta['x-oss-meta-tag0'] \
                    or keyword in meta['x-oss-meta-tag1'] \
                    or keyword in meta['x-oss-meta-tag2'] \
                    or keyword in meta['x-oss-meta-tag3'] \
                    or keyword in meta['x-oss-meta-tag4']:
                targetFile.append(file)
    return targetFile


# searchResults = searchRepo(1, 't')
# print searchResults


def searchAll(repoIds, keyword):
    targetFile = []
    for repoId in repoIds:
        targetFile.append(searchRepo(repoId, keyword))
    return targetFile

# repoIds = [1,2]
# searchResults = searchAll(repoIds, 'zxy')
# print searchResults


def format(localPath, old_pic):
    try:
        bucket.put_object_from_file(old_pic, localPath)
        style = 'image/format,png'
        basepath = os.path.dirname(__file__)
        new_pic = old_pic.rsplit('.')[0]+'_new.png'
        upload_path = basepath + '/static/images/'+new_pic
        bucket.get_object_to_file(old_pic, upload_path, process=style)
        bucket.delete_object(old_pic)
        return 1
    except Exception as e:
        print e
        return 0


# format('/Users/yaolu/Desktop/002.jpg','002.jpg')
