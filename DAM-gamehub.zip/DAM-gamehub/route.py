# -*- coding: utf-8 -*-

from flask import Flask, request, redirect, url_for, render_template, session
import sys
from os import path
from datetime import timedelta
import oss
import sqlfunc as sql

# config
if sys.getdefaultencoding() != 'utf-8':
    reload(sys)
    sys.setdefaultencoding('utf-8')

app = Flask(__name__)

app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = timedelta(seconds=1)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=1)

project_path = path.abspath(path.dirname(__file__))


@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if sql.logIn(request.form['username'], request.form['psw']):
            session['username']=request.form['username']
            return redirect('/mypage')
        else:
            err = 'ERROR : username already exists!'
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        if sql.signUp(request.form['username'], request.form['psw'],0):
            return redirect('/login')
        else:
            err = 'ERROR : username already exists!'
    return render_template('register.html')


@app.route('/mypage', methods=['GET', 'POST'])
def mypage():
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        return redirect('/')
    repo_id=sql.getUserRepoID(session.get('username'))
    repos_info = []
    for i in range(len(repo_id)):
        repo_info = sql.getRepoInfo(repo_id.iloc[i].repo_id)
        print repo_info['repo_id']
        repos_info.append(repo_info)
    return render_template('userpage_repo.html', repos_info=repos_info)


@app.route('/createRepo', methods=['GET', 'POST'])
def createRepo():
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        return redirect('/')
    if request.method == 'POST':
        if sql.createRepo(request.form['repoName'], session['username'], request.form['private'], request.form['description']):
            return redirect('/mypage')
        else:
            err = 'ERROR : repo name already exists!'
    return render_template('userpage_newrepo.html')


@app.route('/repoPage/<repoId>',methods=['GET', 'POST'])
def repoPage(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        return redirect('/')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access this repo!'
        return redirect('/')

    return  render_template('repopage.html', repoId=repoId, repoName=repo_info['repo_name'][0])


@app.route('/repoPage/<repoId>/newResource')
def newResource(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        return redirect('/')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access this repo!'
        return redirect('/')
    return  render_template('repopage_newresour.html', repoId=repoId, repoName=repo_info['repo_name'][0])


@app.route('/repoPage/<repoId>/showRepoResource')
def showRepoResource(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        return redirect('/')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access this repo!'
        return redirect('/')
    return  render_template('repopage_resource.html', repoId=repoId, repoName=repo_info['repo_name'][0])


@app.route('/repoPage/<repoId>/setting')
def repoSetting(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        return redirect('/')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access this repo!'
        return redirect('/')
    return  render_template('repopage_setting.html', repoId=repoId, repoName=repo_info['repo_name'][0])


if __name__ == '__main__':
    app.run(debug=True)