CREATE TABLE Users (
  username varchar(16) NOT NULL,
  password varchar(16) NOT NULL DEFAULT '123456',
  vip smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (username)
)DEFAULT CHARSET=utf8;

CREATE TABLE Repos (
  repo_id int(11) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
  repo_name varchar(50) NOT NULL,
  owner varchar(16) NOT NULL,
  isPrivate boolean NOT NULL,
  description varchar(100) DEFAULT NULL,
  PRIMARY KEY (repo_id),
  FOREIGN KEY (owner) REFERENCES Users(username)
)DEFAULT CHARSET=utf8;

CREATE TABLE Rights (
  username varchar(16) NOT NULL,
  repo_id int(11) UNSIGNED ZEROFILL NOT NULL,
  level boolean NOT NULL,
  PRIMARY KEY (username, repo_id),
  FOREIGN KEY (username) REFERENCES Users(username),
  FOREIGN KEY (repo_id) REFERENCES Repos(repo_id)
)DEFAULT CHARSET=utf8;

CREATE TABLE Logs (
  log_id int(11) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
  repo_id int(11) UNSIGNED ZEROFILL NOT NULL,
  event varchar(300) DEFAULT NULL,
  log_time timestamp NOT NULL,
  PRIMARY KEY (log_id),
  FOREIGN KEY (repo_id) REFERENCES Repos(repo_id)
)DEFAULT CHARSET=utf8;

CREATE TABLE Invitations (
  inv_id int(11) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
  repo_id int(11) UNSIGNED ZEROFILL NOT NULL,
  username varchar(16) NOT NULL,
  level boolean NOT NULL,
  inv_time timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (inv_id),
  FOREIGN KEY (username) REFERENCES Users(username),
  FOREIGN KEY (repo_id) REFERENCES Repos(repo_id)
)DEFAULT CHARSET=utf8;

INSERT INTO Users VALUES ('root', '123456', 2);