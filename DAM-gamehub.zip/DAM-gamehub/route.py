# -*- coding: utf-8 -*-

from flask import Flask, request, redirect, url_for, render_template, session, send_from_directory, abort,flash
import sys
import os
from datetime import timedelta
import oss
import sqlfunc as sql
import utils
from datetime import datetime


# config
if sys.getdefaultencoding() != 'utf-8':
    reload(sys)
    sys.setdefaultencoding('utf-8')

app = Flask(__name__)

app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = timedelta(seconds=1)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=1)

CODE_TYPES=['cs', 'sql', 'c', 'cpp']
MUSIC_TYPES=['mp3','wav']
MODEL_TYPES=['obj','fbx','mat','shader']
PIC_TYPES=['tga','jpg','png','psd','JPG','PNG']
SCENE_TYPES=['unity']
ALL_TYPES=['cs','sql', 'c', 'cpp', 'mp3','wav','obj','fbx','mat','shader','tga','jpg','png','psd','JPG','PNG','unity']


@app.route('/', methods=['GET', 'POST'])
def index():
    if session.get('username')!=None:
        session.pop('username')
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if sql.logIn(request.form['username'], request.form['psw']):
            session['username']=request.form['username']
            if session['username'] == 'root':
                return redirect('/root/list')
            else:
                return redirect('/mypage/all')
        else:
            err = 'ERROR : incorrect username or password!'
            flash(err)
    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        if sql.signUp(request.form['username'], request.form['psw'],0):
            return redirect('/login')
        else:
            err = 'ERROR : username already exists!'
            flash(err)
    return render_template('register.html')


@app.route('/root/<type>', methods=['GET', 'POST'])
def root(type):
    if session.get('username') != 'root':
        err = 'ERROR : you have no access to the root page!'
        flash(err)
        return redirect('/mypage/all')
    if request.method == 'POST':
        if sql.setVip(request.form.get('username'), int(request.form.get('vip'))) == 0:
            err = 'ERROR : set VIP failed! Please make sure that the user exists.'
            flash(err)
        return render_template('rootpage.html')
    elif type == 'set':
        return render_template('rootpage.html')
    else:
        users = sql.showTable('Users')
        users_info = []
        for i in range(users.shape[0]):
             user_info = {'username':users['username'][i], 'vip':users['vip'][i]}
             users_info.append(user_info)
        return render_template('rootpage_list.html',users_info=users_info)


@app.route('/mypage/<type>', methods=['GET', 'POST'])
def mypage(type):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')

    if request.method == 'POST':
        repo_id=sql.searchMyRepo(session.get('username'), request.form.get('keyword'))
    elif type == 'all':
        repo_id=sql.getUserRepoID(session.get('username'))
    elif type == 'create':
        repo_id=sql.getOwnerRepoID(session.get('username'))
    else:
        repo_id=sql.getPartnerRepoID(session.get('username'))
    repos_info = []
    for i in range(len(repo_id)):
        repo_info = sql.getRepoInfo(repo_id.iloc[i].repo_id)
        repos_info.append(repo_info)

    invNum = utils.countInvitations(session['username'])
    return render_template('userpage_repo.html', repos_info=repos_info, type=type, invNum=invNum)


@app.route('/createRepo', methods=['GET', 'POST'])
def createRepo():
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')

    invNum = utils.countInvitations(session['username'])

    if request.method == 'POST':
        if int(request.form['private'])== 1: #  only VIP can generate private repo
            if sql.getVip(session.get('username')) ==-1 or sql.getVip(session.get('username')) ==0:
                err ='ERROR : Vip level too low. You can not generate private repo.'
                flash(err)
                return render_template('userpage_newrepo.html', invNum=invNum)

        if sql.createRepo(request.form['repoName'], session['username'], request.form['private'], request.form['description']):
            repoId = sql.getRepoID(request.form['repoName'], session['username'])
            sql.createLog(repoId, session['username']+' created this repo.', datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            return redirect('/mypage/all')
        else:
            err = 'ERROR : repo name already exists!'
            flash(err)
    return render_template('userpage_newrepo.html', invNum=invNum)


@app.route('/format', methods=['GET', 'POST'])
def format():
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')

    invNum = utils.countInvitations(session['username'])

    utils.del_file(os.path.dirname(__file__) + '/upload')
    utils.del_file(os.path.dirname(__file__) + '/static/images')

    if request.method == 'POST':
        if sql.getVip(session['username']) != 2:
            err = 'ERROR : Only SVIP can transform pictures! Please recharge first.'
            flash(err)
            return redirect('/format')

        # save file on the server
        f = request.files['input-1']
        basepath = os.path.dirname(__file__)
        upload_path = basepath + '/upload/' + f.filename
        f.save(upload_path)
        # upload file from server to OSS and save transformed picture back to server
        if oss.format(upload_path, f.filename)==0:
            err = 'ERROR : transform failed!'
            flash(err)
        new_pic = f.filename.rsplit('.')[0] + '_new.png'

        return render_template('userpage_formatted.html', img_url='images/'+new_pic, invNum=invNum)
    return render_template('userpage_format.html', invNum=invNum)



@app.route('/userpage/allsearch', methods=['POST'])
def userpage_allsearch():
    repo_id = sql.searchAllRepo(request.form.get('keyword'))
    repos_info = []
    for i in range(len(repo_id)):
        repo_info = sql.getRepoInfo(repo_id.iloc[i].repo_id)
        repos_info.append(repo_info)
    invNum = utils.countInvitations(session.get('username'))
    return render_template('userpage_allsearch.html', repos_info=repos_info, invNum=invNum)


@app.route('/repoPage/<repoId>', methods=['GET', 'POST'])
def repoPage(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    invNum = utils.countInvitations(session['username'])
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    logs = sql.getRepoLog(int(repoId))
    logs_info = []
    for i in range(len(logs)):
        log_info = logs.iloc[i]
        logs_info.append(log_info)

    return render_template('repopage.html', repoId=repoId, repoName=repo_info['repo_name'][0], logs_info=logs_info, invNum=invNum)


@app.route('/repoPage/<repoId>/newResource', methods=['GET', 'POST'])
def newResource(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    invNum = utils.countInvitations(session['username'])
    if request.method == 'POST':
        right = sql.getRight(session.get('username'), int(repoId))
        print(right)
        if right ==-1 and session.get('username')!='root' :
            err = 'ERROR : You can not upload. You are not the collaborator of this repo.'
            flash(err)
        else:
            # save file on the server
            flist = request.files.getlist('input1[]')
            basepath = os.path.dirname(__file__)
            for f in flist:
                upload_path = basepath + '/upload/' + f.filename
                f.save(upload_path)
                # upload file from server to OSS
                if oss.uploadFile(repoId, f.filename, upload_path, session['username']) == 0:
                    err = 'ERROR : upload failed!'
                    flash(err)
                # delete file from server
                os.remove(upload_path)
                sql.createLog(repoId, session['username'] + ' uploaded resource "'+f.filename+'"',
                          datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    return render_template('repopage_newresour.html', repoId=repoId, repoName=repo_info['repo_name'][0], invNum=invNum)


@app.route('/repoPage/<repoId>/newFolder', methods=['GET', 'POST'])
def newFolder(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    invNum = utils.countInvitations(session['username'])
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    if request.method == 'POST':
        right = sql.getRight(session.get('username'), int(repoId))
        print(right)
        if right ==-1 and session.get('username')!='root' :
            err = 'ERROR : You can not upload. You are not the collaborator of this repo.'
            flash(err)
        else:
            # save file on the server
            flist = request.files.getlist('input2[]')
            basepath = os.path.dirname(__file__)
            for f in flist:
                fname = f.filename.split('/')
                upload_path = basepath + '/upload/' + fname[-1]
                f.save(upload_path)
                # upload file from server to OSS
                if oss.uploadFile(repoId, fname[-1], upload_path, session['username'])==0:
                    err = 'ERROR : upload failed!'
                    flash(err)
                #delete file from server
                os.remove(upload_path)
                sql.createLog(repoId, session['username'] + ' uploaded resource "' + f.filename + '"',
                              datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    return render_template('repopage_newfolder.html', repoId=repoId, repoName=repo_info['repo_name'][0], invNum=invNum)


@app.route('/repoPage/<repoId>/showRepoResource')
def showRepoResource(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    files_info = []
    try:
        files = oss.listFiles(repoId)
        for file in files:
            file_info = oss.getMeta(repoId, file)
            files_info.append(file_info)
    except Exception as e:
        print(e)
        err = 'ERROR : Connection to the oss failed!'
        flash(err)

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_resource.html',
                           repoId=repoId, repoName=repo_info['repo_name'][0], files_info=files_info, invNum=invNum)


@app.route('/repoPage/<repoId>/setting', methods=['GET', 'POST'])
def repoSetting(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    users_info=sql.getRepoAllRight(int(repoId))
    users=[]
    for i in range(len(users_info)):
        user=users_info.iloc[i]
        users.append(user)

    if request.method == 'POST':
        if session.get('username')!='root' and session.get('username')!= repo_info['owner'][0]:
            err = 'ERROR : You can not change the setting. You are not the owner or administrator.'
            flash(err)
        else:
            if 'form1' in request.form:
                sql.createInvitation(repoId, request.form['username'], int(request.form['level']), datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                return redirect(url_for('repoSetting',repoId=repoId))

            elif 'form2' in request.form:
                if sql.deleteRight(request.form['delete'], int(repoId)) == 0:
                    err = 'ERROR: delete right failed!'
                    flash(err)
                else:
                    sql.createLog(repoId, session['username'] + ' removed ' + request.form[
                        'delete'] + ' from contributors',
                                  datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                    sql.createInvitation(repoId, request.form['delete'], -1, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                    return redirect(url_for('repoSetting', repoId=repoId))

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_setting.html',
                           repoId=repoId, repoName=repo_info['repo_name'][0],users=users,invNum=invNum)


@app.route('/repoPage/<repoId>/code', methods=['GET', 'POST'])
def repopage_code(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    files = oss.listFiles(repoId)
    files_info = []
    for file in files:
        if file.rsplit('.',1)[1] in CODE_TYPES:
            file_info = oss.getMeta(repoId, file)
            files_info.append(file_info)

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_code.html',
                           repoId=repoId, repoName=repo_info['repo_name'][0], files_info=files_info,invNum=invNum)


@app.route('/repoPage/<repoId>/model', methods=['GET', 'POST'])
def repopage_model(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    files = oss.listFiles(repoId)
    files_info = []
    for file in files:
        if file.rsplit('.', 1)[1] in MODEL_TYPES:
            file_info = oss.getMeta(repoId, file)
            files_info.append(file_info)

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_model.html',
                           repoId=repoId, repoName=repo_info['repo_name'][0], files_info=files_info,invNum=invNum)


@app.route('/repoPage/<repoId>/picture', methods=['GET', 'POST'])
def repopage_picture(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    files = oss.listFiles(repoId)
    files_info = []
    for file in files:
        if file.rsplit('.', 1)[1] in PIC_TYPES:
            file_info = oss.getMeta(repoId, file)
            files_info.append(file_info)

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_picture.html',
                           repoId=repoId, repoName=repo_info['repo_name'][0], files_info=files_info,invNum=invNum)


@app.route('/repoPage/<repoId>/scene', methods=['GET', 'POST'])
def repopage_scene(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    files = oss.listFiles(repoId)
    files_info = []
    for file in files:
        if file.rsplit('.', 1)[1] in SCENE_TYPES:
            file_info = oss.getMeta(repoId, file)
            files_info.append(file_info)

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_scene.html',
                           repoId=repoId, repoName=repo_info['repo_name'][0], files_info=files_info, invNum=invNum)


@app.route('/repoPage/<repoId>/music', methods=['GET', 'POST'])
def repopage_music(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    files = oss.listFiles(repoId)
    files_info = []
    for file in files:
        if file.rsplit('.', 1)[1] in MUSIC_TYPES:
            file_info = oss.getMeta(repoId, file)
            files_info.append(file_info)

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_music.html',
                           repoId=repoId, repoName=repo_info['repo_name'][0], files_info=files_info,invNum=invNum)


@app.route('/repoPage/<repoId>/other', methods=['GET', 'POST'])
def repopage_other(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    files = oss.listFiles(repoId)
    files_info = []
    for file in files:
        if file.rsplit('.', 1)[1] not in ALL_TYPES:
            file_info = oss.getMeta(repoId, file)
            files_info.append(file_info)

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_other.html',
                           repoId=repoId, repoName=repo_info['repo_name'][0], files_info=files_info,invNum=invNum)


@app.route('/repoPage/<repoId>/search', methods=['POST'])
def repopage_search(repoId):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    files = oss.searchRepo(repoId, request.form.get('keyword'))
    files_info = []
    for file in files:
        file_info = oss.getMeta(repoId, file.rsplit('/', 1)[1])
        files_info.append(file_info)

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_search.html',
                           repoId=repoId, repoName=repo_info['repo_name'][0], files_info=files_info, invNum=invNum)



@app.route('/repoPage/<repoId>/file/<fileName>', methods=['GET', 'POST'])
def repopage_displayresour(repoId, fileName):
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')
    repo_info = sql.getRepoInfo(int(repoId))
    if repo_info['isPrivate'][0] and sql.getRight(session['username'], int(repoId)) == -1:
        err = 'ERROR : you are not allowed to access that repo!'
        flash(err)
        return redirect('/mypage/all')

    utils.del_file(os.path.dirname(__file__)+'/upload')
    utils.del_file(os.path.dirname(__file__)+'/static/images')
    file_info = oss.getMeta(repoId, fileName)
    img_url = ''
    if fileName.rsplit('.', 1)[1] in PIC_TYPES:
        upload_path = 'static/images/' + fileName
        if oss.downloadFile(repoId, fileName, upload_path):
            img_url='images/'+fileName
        else:
            err='Failed to show image!'
            flash(err)

    if request.method == 'POST':
        print(request.form.get('meta0'))
        print(request.form.get('meta1'))
        print(request.form.get('meta2'))
        print(request.form.get('meta3'))
        print(request.form.get('meta4'))
        tags = [request.form.get('meta0'), request.form.get('meta1'), request.form.get('meta2'),
                request.form.get('meta3'), request.form.get('meta4')]
        if oss.updateMeta(repoId, file_info['fileName'], tags) == 0:
            err = 'ERROR : update metadata failed!'
            flash(err)
        else:
            file_info = oss.getMeta(repoId, fileName)
            sql.createLog(repoId, session['username'] + ' updated metadata of resource ' + fileName,
                          datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    invNum = utils.countInvitations(session['username'])
    return render_template('repopage_displayresour.html', repoId=repoId, repoName=repo_info['repo_name'][0],
                           file_info=file_info, img_url=img_url,invNum=invNum)


@app.route('/repoPage/<repoId>/file/<fileName>/download')
def resource_download(repoId, fileName):
    invNum = utils.countInvitations(session['username'])

    repo_info = sql.getRepoInfo(int(repoId))
    file_info = oss.getMeta(repoId, fileName)
    right = sql.getRight(session.get('username'),  int(repoId))
    if right!=1:
        if right==0:
            err= 'ERROR: Right too low. You can not download file in this repo. You are upload-only.'
            flash(err)
        else :
            err = 'ERROR: You can not download file. You are not the collaborator of this repo.'
            flash(err)
        return render_template('repopage_displayresour.html', repoId=repoId, repoName=repo_info['repo_name'][0],
                               file_info=file_info, invNum=invNum)

    basepath = os.path.dirname(__file__)
    upload_path = basepath + '/upload/' + fileName
    oss.downloadFile(repoId, fileName, upload_path)
    if os.path.isfile(os.path.join('upload', fileName)):
        return send_from_directory('upload', fileName, as_attachment=True,invNum=invNum)
    else:
        abort(404)


@app.route('/repoPage/<repoId>/file/<fileName>/delete')
def resource_delete(repoId, fileName):
    invNum = utils.countInvitations(session['username'])

    repo_info = sql.getRepoInfo(int(repoId))
    file_info = oss.getMeta(repoId, fileName)
    right = sql.getRight(session.get('username'),  int(repoId))
    if right!=1:
        if right==0:
            err= 'ERROR: You can not delete file in this repo. You are an upload-only contributor.'
            flash(err)
        else :
            err = 'ERROR: You can not delete file. You are not the collaborator of this repo.'
            flash(err)
        return render_template('repopage_displayresour.html', repoId=repoId, repoName=repo_info['repo_name'][0],
                               file_info=file_info, invNum=invNum)

    if oss.deleteFile(repoId, fileName):
        sql.createLog(repoId, session['username'] + ' deleted resource ' + fileName,
                      datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        return redirect('/repoPage/'+repoId+'/showRepoResource')
    else:
        err = 'ERROR : delete file failed!'
        flash(err)
        return redirect('/repoPage/' + repoId + '/showRepoResource')


@app.route('/notice', methods=['GET', 'POST'])
def notice():
    if session.get('username') == None:
        err = 'ERROR : you have to log in first!'
        flash(err)
        return render_template('login.html')

    invNum = utils.countInvitations(session['username'])

    invitations_info = sql.getInvByUsername(session['username'])
    invitations = []
    for i in range(len(invitations_info)):
        invitation = invitations_info.iloc[i]
        invitations.append(invitation)

    if request.method == 'GET':
        return render_template('notice.html', invitations=invitations, invNum=invNum)

    if request.method == 'POST':
        for inv in invitations:
            if inv['level'] == 1 or inv['level'] == 0:
                id = str(inv['inv_id'])
                if request.form[id] == '1':
                    if sql.getRight(session['username'], int(inv['repo_id'])) == -1:
                        sql.createRight(session['username'], int(inv['repo_id']), inv['level'])
                    else:
                        sql.setRight(session['username'], int(inv['repo_id']), inv['level'])
                    sql.createLog(inv['repo_id'], session['username']+' is invited as a collaborator of repo '+inv['repo_name'],datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        sql.deleteInvByUsername(session['username'])
        return redirect('/notice')

if __name__ == '__main__':
    app.run(debug=True)